package com.example.myfinalproject2048;

import java.util.Random;

public class BoardGame {
    private int size = 4;
    private int[][] grid;

    public BoardGame() {
        grid = new int[size][size];
        reset();
    }

    // מאפס לוח ומוסיף 2 מספרים להתחלה
    public void reset() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                grid[i][j] = 0;
            }
        }

        addRandomTile();
        addRandomTile();
    }

    //מוסיף מספר רנדומלי
    public void addRandomTile(){
        
    }
}
