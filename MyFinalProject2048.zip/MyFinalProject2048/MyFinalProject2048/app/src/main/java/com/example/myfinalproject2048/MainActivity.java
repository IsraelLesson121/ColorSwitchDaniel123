package com.example.myfinalproject2048;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnStartGame;
    Button btnGameInstructions;
    Button btnRecords;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnStartGame = findViewById(R.id.btnStartGame);
        btnGameInstructions = findViewById(R.id.btnGameInstructions);
        btnRecords = findViewById(R.id.btnRecords);

        btnStartGame.setOnClickListener(this);
        btnGameInstructions.setOnClickListener(this);
        btnRecords.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent = new Intent(MainActivity.this, StartGame.class);
        startActivity(intent);
        Intent intent2 = new Intent(MainActivity.this, GameInstructions.class);
        startActivity(intent);
        Intent intent3 = new Intent(MainActivity.this, Records.class);
        startActivity(intent);
        }
    }