package com.example.myfinalproject2048;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameManager {
    public int[][] board = new int[4][4];
    public int score = 0;
    private Random rnd = new Random();

    // התחלת המשחק
    public void startGame() {
        // מאפסים את הלוח
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
                board[i][j] = 0;

        // מוסיפים 2 מספרים התחלתיים
        generateNewTile();
        generateNewTile();
    }

    // הוספת מספר חדש (2 או 4) בתא ריק
    public void generateNewTile() {
        List<int[]> emptyCells = new ArrayList<>();

        // מוצאים את כל התאים הריקים
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (board[i][j] == 0) {
                    emptyCells.add(new int[]{i, j});
                }
            }
        }

        if (emptyCells.size() == 0) return; // אין מקום חדש

        // בוחרים תא ריק אקראי
        int[] cell = emptyCells.get(rnd.nextInt(emptyCells.size()));

        // שמים 2 או 4
        board[cell[0]][cell[1]] = rnd.nextDouble() < 0.9 ? 2 : 4;
    }

    // הזזת המספרים שמאלה
    public void moveLeft() {
        for (int i = 0; i < 4; i++) {
            int[] row = board[i];
            int[] newRow = new int[4];
            int pos = 0;

            // שמים את המספרים הלא אפסים בשורה החדשה
            for (int j = 0; j < 4; j++) {
                if (row[j] != 0) {
                    newRow[pos++] = row[j];
                }
            }

            // איחוד מספרים זהים
            for (int j = 0; j < 3; j++) {
                if (newRow[j] != 0 && newRow[j] == newRow[j + 1]) {
                    newRow[j] *= 2;
                    score += newRow[j];
                    newRow[j + 1] = 0;
                }
            }

            // סידור מחדש אחרי האיחוד
            int[] finalRow = new int[4];
            pos = 0;
            for (int j = 0; j < 4; j++) {
                if (newRow[j] != 0) {
                    finalRow[pos++] = newRow[j];
                }
            }

            board[i] = finalRow;
        }
        generateNewTile();
    }

    // פונקציות להזזה ימינה, למעלה ולמטה
    public void moveRight() {
        rotateBoard180();
        moveLeft();
        rotateBoard180();
    }

    public void moveUp() {
        rotateBoardCounterClockwise();
        moveLeft();
        rotateBoardClockwise();
    }

    public void moveDown() {
        rotateBoardClockwise();
        moveLeft();
        rotateBoardCounterClockwise();
    }

    // פונקציות עזר לסיבוב הלוח
    private void rotateBoardClockwise() {
        int[][] newBoard = new int[4][4];
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
                newBoard[j][3 - i] = board[i][j];
        board = newBoard;
    }

    private void rotateBoardCounterClockwise() {
        int[][] newBoard = new int[4][4];
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
                newBoard[3 - j][i] = board[i][j];
        board = newBoard;
    }

    private void rotateBoard180() {
        rotateBoardClockwise();
        rotateBoardClockwise();
    }

    // בדיקה אם אפשר להזיז
    public boolean canMove() {
        // אם יש תא ריק → אפשר להזיז
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
                if (board[i][j] == 0) return true;

        // בדיקה אם יש מספרים סמוכים זהים
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 3; j++)
                if (board[i][j] == board[i][j + 1]) return true;

        for (int j = 0; j < 4; j++)
            for (int i = 0; i < 3; i++)
                if (board[i][j] == board[i + 1][j]) return true;

        return false;
    }
}
