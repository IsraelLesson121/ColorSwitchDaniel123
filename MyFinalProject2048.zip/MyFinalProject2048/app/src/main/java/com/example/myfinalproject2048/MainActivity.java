package com.example.myfinalproject2048;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnStartGame;
    Button btnInstructions;
    Button btnRecords;
    Intent StartGameActivity, InstructionsActivity, RecordsActivity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnStartGame = findViewById(R.id.btnStartGame);
        btnInstructions = findViewById(R.id.btnInstructions);
        btnRecords = findViewById(R.id.btnRecords);

        btnStartGame.setOnClickListener(this);
        btnInstructions.setOnClickListener(this);
        btnRecords.setOnClickListener(this);

    }

    @Override public void onClick(View view) {
        // בדיקה איזה כפתור נלחץ
        if (view.getId() == R.id.btnStartGame) {

            StartGameActivity = new Intent(MainActivity.this, StartGameActivity.class);
            startActivity(StartGameActivity);

        } else if (view.getId() == R.id.btnInstructions) {

            InstructionsActivity = new Intent(MainActivity.this, InstructionsActivity.class);
            startActivity(InstructionsActivity);

        } else if (view.getId() == R.id.btnRecords) {

            RecordsActivity = new Intent(MainActivity.this, RecordsActivity.class);
            startActivity(RecordsActivity);
        }
    }
}