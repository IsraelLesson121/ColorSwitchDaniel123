package com.example.myfinalproject2048;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BoardGame {
    public static class boardGame {

        private final int size = 4;       // גודל הלוח 4x4
        private int[][] board;            // המערך שמחזיק את המספרים
        private Random rnd = new Random();      // הוספת מספרים רנדומליים(2 או 4)
        private int score;                // ניקוד השחקן

        public boardGame() {
            board = new int[size][size];
            rnd = new Random();
            score = 0;
        }
    }
}